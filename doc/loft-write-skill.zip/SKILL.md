---
name: loft-write
description: Reference for writing correct loft code. Apply whenever writing, editing, or reviewing .loft files. Covers types, syntax, known bugs, workarounds, and naming rules.
user-invocable: false
---

# Loft Language Writing Reference

Always consult this before writing or reviewing `.loft` files.

## Types

| Loft type | Notes |
|-----------|-------|
| `integer` | i32. Null sentinel is `i32::MIN` — avoid overflow (e.g. LCG arithmetic) |
| `long` | i64. Literal suffix `l`: `0l`, `1000l` |
| `float` | f64. Literal: `1.0`, `0.5` |
| `boolean` | `true` / `false` |
| `string` | UTF-8. Template strings: `"value is {expr}"` |
| `vector<T>` | Ordered list. Comprehension: `[for x in range { expr }]` |
| `hash<S[field]>` | Hash-map keyed by `field` on struct `S`. **Must be a struct field — not a standalone local variable** |

## Struct definitions

```loft
struct Point { x: float, y: float }
struct Bag { items: hash<Point[x]> }   // hash must live in a struct
```

## Variable declarations

Variables are declared by assignment. **No type annotations on local variables** — the type is inferred from the initialiser. The annotation syntax is only valid in function signatures.

```loft
// WRONG
xs: vector<integer> = [1, 2, 3];

// CORRECT
xs = [1, 2, 3];
```

## Function signatures

```loft
fn name(param: Type, ref_param: &Type, const_param: const Type) -> ReturnType {
  // body
}
```

- `const T` — immutable reference (pass-by-ref, caller unchanged)
- `&T` — mutable reference
- Omit modifier — pass by value / copy

## Collections

### Vector literals and comprehensions

```loft
empty = [for dummy in 0..0 { dummy }];   // empty vector<integer>
nums  = [for i in 0..10 { i * 2 }];      // [0,2,4,...,18]
```

### Append

```loft
v += [element];     // append one element
v += other_vec;     // concatenate
```

### Indexing

```loft
v[i]               // read element
// v[i] = x        // NOT valid on owned local — needs &vector<T> ref param
```

### Slices return iterators, not vectors

`arr[lo..hi]` returns an iterator. It **cannot** be passed where a `vector<T>` is expected. Use index bounds instead:

```loft
// WRONG — slice is not a vector
fn process(sub: const vector<integer>) { ... }
process(arr[lo..hi]);   // type error

// CORRECT — pass full array + bounds
fn process(arr: const vector<integer>, lo: integer, hi: integer) { ... }
```

### Hash (must be struct field)

```loft
struct WordEntry { text: string, count: integer }
struct DB { freq: hash<WordEntry[text]> }

db = DB { freq: [] };
db.freq += [WordEntry { text: "hello", count: 1 }];
entry = db.freq["hello"];
if entry == null { /* not found */ }
else { entry.count += 1; }
// Hashes cannot be iterated directly — track aggregates separately
```

## For loops

```loft
for var in 0..n { body }           // exclusive upper bound
for var in 0..=n { body }          // inclusive upper bound
result = [for var in 0..n { expr }]; // comprehension — returns vector
```

### CRITICAL — flat namespace

**All variable names across every function in a file share one global namespace.** This includes parameters, local variables, and loop variables. Name conflicts across functions cause codegen panics or wrong behaviour.

Rules:
- Use unique loop variable names across all functions in the file (e.g. `mb_i`, `mb_x`, `ms_init`, `col_i`)
- Never reuse a loop variable name in a different function
- Parameters also occupy the global namespace — use descriptive names

### Unused variable warning = exit 1

If a loop variable is declared but never read, loft emits a warning and exits with code 1. Either use the variable in the body or give it a meaningful use (even trivially):

```loft
// Avoid naming a loop var if you only need the count:
for step in 0..n {
  // if step is unused, loft exits 1
}
// Workaround: use _ for the loop var when value is unused
for _ in 0..n { ... }
```

However `_` also occupies the flat namespace — if two functions both use `for _ in ...` there may be conflicts. Use unique named variables when functions call each other recursively.

### `const vector<T>` recursive call bug

When a function has `const vector<T>` parameters **and** calls itself recursively **and** the callee function contains a `for` loop, the codegen can panic with "Too few parameters". Workaround approaches:
- Remove the `for` loop from the function receiving `const vector<T>` params and use recursion instead
- Or restructure to avoid recursive `const vector<T>` across the call boundary

## Control flow

```loft
if cond { ... } else if cond { ... } else { ... }
return expr;
break;          // exit a for loop
```

## Builtin functions and reserved names

**Do not shadow these names** — using them as variable names causes runtime errors or silent wrong results:

| Name | What it is |
|------|-----------|
| `len` | `len(collection) -> integer` |
| `ticks` | `ticks() -> long` — microseconds since epoch |
| `round` | `round(float) -> long` |
| `sorted` | keyword / builtin — do not use as a variable name |
| `null` | null literal |

## Stdlib print

```loft
println("text {expr} more");   // NOT say(), NOT print()
```

## Integer / long arithmetic

```loft
ms = (ticks() - t0) / 1000l;   // ticks() returns long; divide by long literal
x as long                        // cast integer to long
x as float                       // cast integer to float
```

Avoid operations that produce `i32::MIN` (null): large multiplications, LCG seeds, etc.

## Boolean in structs

`boolean` struct fields can cause compiler panics in some versions. Use `integer` with 0/1 sentinel instead when writing struct fields that represent booleans.

## CLI invocation

```bash
loft --path /path/to/repo/ file.loft           # interpreter
loft --native --path /path/to/repo/ file.loft  # compile + run native
loft --native-wasm out.wasm --path /path/to/repo/ file.loft  # compile to wasm
```

`--path` must have a **trailing slash** — loft concatenates `"default"` directly onto the path string.

## Checklist before finishing a .loft file

- [ ] All loop variables are unique across the entire file
- [ ] No local variables have type annotations
- [ ] No hash variables declared outside a struct
- [ ] No `arr[lo..hi]` passed as `vector<T>` argument
- [ ] `len`, `sorted`, `ticks`, `round` are not used as variable names
- [ ] Print calls use `println()` not `say()`
- [ ] Long literals use `l` suffix where needed
- [ ] `--path` ends with `/` in CLI calls
